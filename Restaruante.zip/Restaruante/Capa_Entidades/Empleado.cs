﻿namespace Capa_Entidades
{
    public class Empleado
    {
        string Nombre;
        int Id;
        string Sexo;

        public Empleado()
        {

        }
        public Empleado(string Nombre, int Id, string Sexo)
        {
            this.Nombre = Nombre;
            this.Id = Id;
            this.Sexo = Sexo;

        }
        public void setNombre(string Nombre) { this.Nombre = Nombre; }
        public string getNombre() { return this.Nombre; }
        public   { this.Id = Id; }
        public int getId() { return this.Id; }
        public void setSexo(string Sexo) { this.Sexo = Sexo; }
        public string getSexo() { return this.Sexo; }
    }
}