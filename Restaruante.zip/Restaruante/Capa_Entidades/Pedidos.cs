﻿
namespace Capa_entidades
{
    public class Pedidos
        string Pedido_comida;
        int Precio;
        public Pedidos(string pedido_comida, int precio)
        {
            Pedido_comida = pedido_comida;
            Precio = precio;
        }
        public void setPedido_comida(string Pedido_comida) { this.Pedido_comida = Pedido_comida; }
        public string getPedido_comida() { return this.Pedido_comida; }
        public int precio { get => Precio; set => Precio = value; }
    }

}